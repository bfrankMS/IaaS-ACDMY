﻿<#
    Bootcamp: Intelligent Cloud Bootcamp Azure IaaS Cloud Expert

    ***************************************

        ...................

    ***************************************
    This script will 

    see: 

    by: bfrank
    version: 1.0.0.0
#>

#you might want to update - here is the command
Install-Module Az #-AllowClobber